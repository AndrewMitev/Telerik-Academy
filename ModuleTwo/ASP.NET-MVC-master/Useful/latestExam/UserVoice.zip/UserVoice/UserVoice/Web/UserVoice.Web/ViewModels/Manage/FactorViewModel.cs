﻿namespace UserVoice.Web.Models.Manage
{
    public class FactorViewModel
    {
        public string Purpose { get; set; }
    }
}