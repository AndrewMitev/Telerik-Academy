MyWebApi - ASP.NET Web API Fluent Testing Framework

MyWebApi is licensed under the GNU General Public Licence v3.
Basically:
 - If you create software that uses GPL, you must license that software under GPL v3
 - If you create software that uses GPL, you must release your source code
 - If you start with a GPL license, you cannot convert to another license
 - You cannot include MyWebApi in a closed source distribution under this license 

If you have a really-coolish-and-nice open source or 
just closed source commercial project and you want to
include MyWebApi in it, leave a question on the issues page at
https://github.com/ivaylokenov/MyWebApi/issues and another license 
with the latest version of the library will be provided free of charge to you.
 
Copyright (C) 2015 Ivaylo Kenov.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/.