﻿namespace ConsoleWebServer.Framework
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Text;

    public class HttpResponse
    {
        public const string ContentTypeConstant = "text/plain; charset=utf-8";
        private string serverEngineName;

        public HttpResponse(IActionResult action)
            : this(action.Request.ProtocolVersion, action.StatusCode, action.GetContent(), action.ContentType)
        {
        }

        public HttpResponse(Version httpVersion, HttpStatusCode statusCode, string body, string contentType = ContentTypeConstant)
        {
            this.serverEngineName = "ConsoleWebServer";
            this.ProtocolVersion = Version.Parse(httpVersion.ToString()
                .ToLower()
                .Replace("HTTP/".ToLower(), string.Empty));

            this.Headers = new SortedDictionary<string, ICollection<string>>();

            this.Body = body;

            this.StatusCode = statusCode;
            this.AddHeader("Server", this.serverEngineName);
            this.AddHeader("Content-Length", body.Length.ToString());
            this.AddHeader("Content-Type", contentType);
        }

        public Version ProtocolVersion { get; protected set; }

        public IDictionary<string, ICollection<string>> Headers { get; protected set; }

        public HttpStatusCode StatusCode { get; private set; }

        public string Body { get; private set; }

        public string StatusCodeAsString
        {
            get
            {
                return this.StatusCode.ToString();
            }
        }

        public void AddHeader(string name, string value)
        {
            if (!this.Headers.ContainsKey(name))
            {
                this.Headers.Add(name, new HashSet<string>());
            }

            this.Headers[name].Add(value);
        }

        public override string ToString()
        {
            var stringBuilder = new StringBuilder();
            stringBuilder.AppendLine(
                string.Format(
                    "{0}{1} {2} {3}",
                    "HTTP/",
                    this.ProtocolVersion,
                    (int)this.StatusCode,
                    this.StatusCodeAsString));

            var headerStringBuilder = new StringBuilder();

            foreach (var key in this.Headers.Keys)
            {
                headerStringBuilder.AppendLine(string.Format("{0}: {1}", key, string.Join("; ", this.Headers[key])));
            }

            stringBuilder.AppendLine(headerStringBuilder.ToString());

            if (!string.IsNullOrWhiteSpace(this.Body))
            {
                stringBuilder.AppendLine(this.Body);
            }

            return stringBuilder.ToString();
        }
    }
}